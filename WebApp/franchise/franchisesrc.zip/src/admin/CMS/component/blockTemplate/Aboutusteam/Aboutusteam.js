import React, { Component } from 'react';
import "./Aboutusteam.css";

export default class Aboutusteam extends Component {
	constructor(props){
    super(props);
	    this.state = {
	    	
	    };
  	}  
  render() {
		return (
			<div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center mt50">
				<div className="row mt50">
					<div className="col-lg-12">
						<h2 className="col-lg-12 mt50">Our Team</h2>
						<p className="col-lg-12 mt20">Multistore vision is to create India's most reliable and frictionless commerce ecosystem that <br/>creates life-changing experiences for buyers and sellers.</p>
					</div>
					<div className="col-lg-10 col-lg-offset-1 text-center">
						<div className="col-lg-3 mt50">
							<div className="teamcontainerimg">
							  <img src="images/userimg.png" alt="Avatar" className="image" />
							  <div className="col-lg-12">
								  <div className="col-lg-12 teamcontainertext">
								  	<h4><b>Andrew Flintoft</b></h4>
								  	<h5>Co-Founder</h5>
								  </div>
							  </div>
							  <div className="middle">
							    <div className="text"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p></div>
							  </div>
							</div>
						 </div>
						<div className="col-lg-3 mt50">
							<div className="teamcontainerimg">
							  <img src="images/userimg.png" alt="Avatar" className="image" />
							  <div className="col-lg-12">
								  <div className="col-lg-12 teamcontainertext">
								  	<h4><b>Andrew Flintoft</b></h4>
								  	<h5>Co-Founder</h5>
								  </div>
							  </div>
							  <div className="middle">
							    <div className="text"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p></div>
							  </div>
							</div>
						 </div>
						<div className="col-lg-3 mt50">
							<div className="teamcontainerimg">
							  <img src="images/userimg.png" alt="Avatar" className="image" />
							  <div className="col-lg-12">
								  <div className="col-lg-12 teamcontainertext">
								  	<h4><b>Andrew Flintoft</b></h4>
								  	<h5>Co-Founder</h5>
								  </div>
							  </div>
							  <div className="middle">
							    <div className="text"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p></div>
							  </div>
							</div>
						 </div>
						<div className="col-lg-3 mt50">
							<div className="teamcontainerimg">
							  <img src="images/userimg.png" alt="Avatar" className="image" />
							  <div className="col-lg-12">
								  <div className="col-lg-12 teamcontainertext">
								  	<h4><b>Andrew Flintoft</b></h4>
								  	<h5>Co-Founder</h5>
								  </div>
							  </div>
							  <div className="middle">
							    <div className="text"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p></div>
							  </div>
							</div>
						 </div>
					 </div>
				</div>
			</div>
		);
	}
}