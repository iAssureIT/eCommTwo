import React from 'react';

export default class BlockDesignsList extends React.Component {
	constructor(props) {
		super(props);
	}
	componentDidMount(){
	}

	render() {
		return (
			<div>
				{/*<div> <Aboutustextcenter /> </div>
				<div> <Aboutusimgright /> </div>*/}
			</div>
		);
	}
}
