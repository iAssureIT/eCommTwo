import React from 'react';

export default class selectPagePattern extends React.Component {

	constructor(props) {
		super(props);
	}

	render() {
		return (
			<div></div>
		);
	}
}
