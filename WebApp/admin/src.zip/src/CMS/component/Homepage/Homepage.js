import React from 'react';/*
import HomepageBanner from '../blockTemplate/HomepageBanner/HomepageBanner.js';
import Homepagebuttononimage from '../blockTemplate/Homepagebuttononimage/Homepagebuttononimage.js';
import Homepagefeature from '../blockTemplate/Homepagefeature/Homepagefeature.js';
import Homepageintrovideo from '../blockTemplate/Homepageintrovideo/Homepageintrovideo.js';
import HomepageInvisalign from '../blockTemplate/HomepageInvisalign/HomepageInvisalign.js';
import Homepagepromotions from '../blockTemplate/Homepagepromotions/Homepagepromotions.js';
import Footer from '../blockTemplate/Footer/Footer.js';
import BannerContactUs from '../blockTemplate/BannerContactUs/BannerContactUs.js';
import CUform from '../blockTemplate/CUform/CUform.js';
import ContactShopList from '../blockTemplate/ContactShopList/ContactShopList.js';
import CUMap from '../blockTemplate/CUMap/CUMap.js';
import HeaderTrueU from '../blockTemplate/HeaderTrueU/HeaderTrueU.js';
import WhoWeAre from '../blockTemplate/WhoWeAre/WhoWeAre.js';
*/

export default class Homepage extends React.Component {


	constructor(props) {
		super(props);
	}

	render() {
		return (
			<div>
				{/*<HeaderTrueU/>
				<HomepageBanner/>
				<WhoWeAre/>
				<Homepagebuttononimage/>
				<Homepagefeature/>
				<Homepageintrovideo/>
				<HomepageInvisalign/>
				<Homepagepromotions/>
				<Footer/>*/}
				{/*<BannerContactUs/>
				<CUform/>
				<ContactShopList/>
				<CUMap/>*/}
			</div>
		);
	}
}
