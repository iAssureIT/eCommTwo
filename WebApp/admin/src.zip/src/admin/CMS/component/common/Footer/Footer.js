import React, {Component} from 'react';
import "./footer.css";

export default class Footer extends Component{
	constructor(props){
		super(props);
		this.state = {
		};		
	}


	render(){
		return (
			<div className="row">
			<br/>
		
				<footer className="footerComp bg-success">	

	    	</footer>	
    	</div>
		);
	};
}


