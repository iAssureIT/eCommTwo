import React, { Component } from 'react';
import "./Aboutushistory.css";

export default class Aboutushistory extends Component {
	constructor(props){
    super(props);
	    this.state = {
	    	
	    };
  	}  
  render() {
		return (
			<div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center mt50">
				<div className="row">
					<div className="container-time col-lg-10 col-lg-offset-1">
					<div className="page-header-time">
					<h1 id="timeline">Our history</h1>
					</div>
					<ul className="timeline">
					<li className="timeline-year-li">
					<div className="timeline-year">2014</div>
					</li>
					<li className="count-li">
					<div className="timeline-badge"></div>
					<div className="timeline-panel animation-element banner-nb-bottom in-view">
					<div className="img-text"><img src="http://demo8.cmsmart.net/mag2_amazon_themeforest/pub/media/multistore/banner/Untitled-1-01.png" alt=""/></div>
					<div className="timeline-body">
					<h4 className="timeline-title">Mussum ipsum cacilds</h4>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...</p>
					</div>
					</div>
					</li>
					<li className="timeline-inverted count-li">
					<div className="timeline-badge"></div>
					<div className="timeline-panel  animation-element banner-nb-bottom">
					<div className="img-text"><img src="http://demo8.cmsmart.net/mag2_amazon_themeforest/pub/media/multistore/banner/Untitled-1-02.png" alt=""/></div>
					<div className="timeline-body">
					<h4 className="timeline-title">Mussum ipsum cacilds</h4>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...</p>
					</div>
					</div>
					</li>
					<li className="timeline-year-li">
					<div className="timeline-year">2015</div>
					</li>
					<li className="count-li">
					<div className="timeline-badge"></div>
					<div className="timeline-panel  animation-element banner-nb-bottom">
					<div className="img-text"><img src="http://demo8.cmsmart.net/mag2_amazon_themeforest/pub/media/multistore/banner/Untitled-1-03.png" alt=""/></div>
					<div className="timeline-body">
					<h4 className="timeline-title">Mussum ipsum cacilds</h4>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...</p>
					</div>
					</div>
					</li>
					<li className="timeline-inverted count-li">
					<div className="timeline-badge"></div>
					<div className="timeline-panel  animation-element banner-nb-bottom">
					<div className="img-text"><img src="http://demo8.cmsmart.net/mag2_amazon_themeforest/pub/media/multistore/banner/Untitled-1-04.png" alt=""/></div>
					<div className="timeline-body">
					<h4 className="timeline-title">Mussum ipsum cacilds</h4>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...</p>
					</div>
					</div>
					</li>
					<li className="count-li">
					<div className="timeline-badge"></div>
					<div className="timeline-panel  animation-element banner-nb-bottom">
					<div className="img-text"><img src="http://demo8.cmsmart.net/mag2_amazon_themeforest/pub/media/multistore/banner/Untitled-1-05.png" alt=""/></div>
					<div className="timeline-body">
					<h4 className="timeline-title">Mussum ipsum cacilds</h4>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...</p>
					</div>
					</div>
					</li>
					<li className="timeline-year-li">
					<div className="timeline-year">2016</div>
					</li>
					<li className="timeline-inverted count-li">
					<div className="timeline-badge"></div>
					<div className="timeline-panel  animation-element banner-nb-bottom">
					<div className="img-text"><img src="http://demo8.cmsmart.net/mag2_amazon_themeforest/pub/media/multistore/banner/Untitled-1-06.png" alt=""/></div>
					<div className="timeline-body">
					<h4 className="timeline-title">Mussum ipsum cacilds</h4>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...</p>
					</div>
					</div>
					</li>
					</ul>
					</div>				
				</div>
			</div>
		);
	}
}